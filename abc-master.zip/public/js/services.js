var baseUrl = 'http://localhost:4040'
$(document).ready(function(){
  $('#categories').selectize({
    plugins: ['remove_button', 'restore_on_backspace','drag_drop'],
    delimiter: ';',
    persist: false,
    maxItems: 5,
    create: function(input) {
        return {
            // value: input,
            // text: input
            genre: input
        }
    },
    createOnBlur: true,
    openOnFocus: false,
    valueField: 'genre',
    labelField: 'genre',
    searchField: 'genre',
    options: [],
    onItemAdd: function() {
      this.close();
    },
    //- create: false,
    render: {
      option: function(item, escape) {
        var genres = [];
        for (var i = 0, n = item.genre.length; i < n; i++) {
          genres.push('<span>' + escape(item.genre) + '</span>');
        }

        return '<div><span class="name">' + escape(item.genre) + '</span></div>';
      }
    },
    load: function(query, callback) {
      if (!query.length) return callback();
      $.ajax({
        url: baseUrl+'/list/genres',
        type: 'GET',
        dataType: 'json',
        //- contentType: "application/json; charset=utf-8",
        //- crossDomain: true,
        //- beforeSend: setRequestHeader("Access-Control-Allow-Origin", "*"),
        data: {
          q: query,
          limit: 5
        },
        error: function(e) {
          console.log('Error: ', e.message)
          callback();
        },
        success: function(res) {
          callback(res);
        }
      });
    }
  });

  $('#language').selectize({
    valueField: 'language',
    labelField: 'language',
    searchField: 'language',
    create: false,
    maxItems: 1,
    render: {
      option: function(item, escape) {
        var languages = [];
        for (var i = 0, n = item.language.length; i < n; i++) {
          languages.push('<span>' + escape(item.language) + '</span>');
        }

        return '<div><span class="name">' + escape(item.language) + '</span></div>';
      }
    },
    load: function(query, callback) {
        if (!query.length) return callback();
        $.ajax({
          url: baseUrl+'/list/languages',
          type: 'GET',
          dataType: 'json',
          data: {
            q: query,
            limit: 5
          },
          error: function(e) {
            console.log('Error: ', e.message)
            callback();
          },
          success: function(res) {
            callback(res);
          }
        });
      }
  });

  $('#nationality').selectize({
    plugins: ['remove_button', 'restore_on_backspace','drag_drop'],
    delimiter: ';',
    persist: false,
    maxItems: 5,
    create: function(input) {
        return {
            // value: input,
            // text: input
            nationality: input
        }
    },
    createOnBlur: true,
    openOnFocus: false,
    valueField: 'nationality',
    labelField: 'nationality',
    searchField: 'nationality',
    options: [],
    onItemAdd: function() {
      this.close();
    },
    //-create: false,
    maxItems: 5,
    render: {
      option: function(item, escape) {
        var languages = [];
        for (var i = 0, n = item.nationality.length; i < n; i++) {
          languages.push('<span>' + escape(item.nationality) + '</span>');
        }

        return '<div><span class="name">' + escape(item.nationality) + '</span></div>';
      }
    },
    load: function(query, callback) {
        if (!query.length) return callback();
        $.ajax({
          url: baseUrl+'/list/nationalities',
          type: 'GET',
          dataType: 'json',
          data: {
            q: query,
            limit: 5
          },
          error: function(e) {
            console.log('Error: ', e.message)
            callback();
          },
          success: function(res) {
            callback(res);
          }
        });
      }
  });

  $('#occupation').selectize({
    plugins: ['remove_button', 'restore_on_backspace','drag_drop'],
    delimiter: ';',
    persist: false,
    maxItems: 10,
    create: function(input) {
        return {
            // value: input,
            // text: input
            occupation: input
        }
    },
    createOnBlur: true,
    openOnFocus: false,
    valueField: 'occupation',
    labelField: 'occupation',
    searchField: 'occupation',
    options: [],
    onItemAdd: function() {
      this.close();
    },
    //-create: false,
    maxItems: 10,
    render: {
      option: function(item, escape) {
        var languages = [];
        for (var i = 0, n = item.occupation.length; i < n; i++) {
          languages.push('<span>' + escape(item.occupation) + '</span>');
        }

        return '<div><span class="name">' + escape(item.occupation) + '</span></div>';
      }
    },
    load: function(query, callback) {
        if (!query.length) return callback();
        $.ajax({
          url: baseUrl+'/list/occupations',
          type: 'GET',
          dataType: 'json',
          data: {
            q: query,
            limit: 20
          },
          error: function(e) {
            console.log('Error: ', e.message)
            callback();
          },
          success: function(res) {
            callback(res);
          }
        });
      }
  });

  $('#keywords').selectize({
    plugins: ['remove_button', 'restore_on_backspace','drag_drop'],
    delimiter: ';',
    persist: false,
    create: function(input) {
        return {
            // value: input,
            // text: input
            genre: input
        }
    },
    createOnBlur: true,
    openOnFocus: false,
    valueField: 'keyword',
    labelField: 'keyword',
    searchField: 'keyword',
    options: [],
    onItemAdd: function() {
      this.close();
    },
    //- create: false,
    render: {
      option: function(item, escape) {
        var tags = [];
        for (var i = 0, n = item.keyword.length; i < n; i++) {
          tags.push('<span>' + escape(item.keyword) + '</span>');
        }

        return '<div><span class="name">' + escape(item.keyword) + '</span></div>';
      }
    },
    load: function(query, callback) {
      if (!query.length) return callback();
      $.ajax({
        url: baseUrl+'/list/tags',
        type: 'GET',
        dataType: 'json',
        data: {
          q: query,
          limit: 5
        },
        error: function(e) {
          console.log('Error: ', e.message)
          callback();
        },
        success: function(res) {
          callback(res);
        }
      });
    }
  });

  if(window.location.pathname.indexOf('/account/profile') != -1){
    $('#profilePage').tabCollapse();
  }

  if(window.location.pathname == '/account/profile/basic') {
    $("#contact").intlTelInput({
        initialCountry: "auto",
        nationalMode: false,
        geoIpLookup: function(callback) {
          $.get("https://ipinfo.io", function() {}, "jsonp").always(function(resp) {
            var countryCode = (resp && resp.country) ? resp.country : "";
            callback(countryCode);
          });
        },
        customPlaceholder: function(selectedCountryPlaceholder, selectedCountryData) {
          return "e.g. " + selectedCountryPlaceholder;
        },
        utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/8.4.6/js/utils.js"
    });
  }
})
