var countryDao = {};
const Country = require('../model').countries;

countryDao.listCountry = (query, pageLimit) => {
  return Country.find({
      country: new RegExp(query, "i")
  },
  { _id: 0},
  {limit: parseInt(pageLimit)})
    .lean().exec()
}

countryDao.listAllCountry = () => {
  return Country.find({},{ _id: 0})
    .lean().exec()
}

module.exports = countryDao
