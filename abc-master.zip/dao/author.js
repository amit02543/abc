var authorDao = {}
var Author = require('../model').author;

authorDao.insertAuthorDetails = (author) => {
  var doc = new Author(author);
  return doc.save()
}

authorDao.getAllAuthors = () => {
  return Author.find()
}

authorDao.getTopAuthors = () => {
  return Author.find().sort({likes: -1}).limit(10)
}

authorDao.getAuthorDetailsById = (id) => {
  return Author.find({
    _id: id
  })
  .sort({genre: 1})
  .limit(10)
}
9959808314

module.exports = authorDao
