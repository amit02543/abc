var queryDao = {};
const UserQuery = require('../model').userquery;

queryDao.insertUserQuery = (q) => {
  var doc = new UserQuery(q);
  return doc.save()
}

module.exports = queryDao
