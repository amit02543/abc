const bookDao = require('./books')
const queryDao = require('./user-query')
const authorDao = require('./author')
const publisherDao = require('./publisher')
const genreDao = require('./genre')
const countryDao = require('./country')
const languageDao = require('./language')
const nationalityDao = require('./nationality')
const occupationDao = require('./occupation')
const tagDao = require('./tag')

module.exports = {
  book: bookDao,
  author: authorDao,
  publisher: publisherDao,
  query: queryDao,
  genre: genreDao,
  country: countryDao,
  language: languageDao,
  nationality: nationalityDao,
  occupation: occupationDao,
  tag: tagDao
}
