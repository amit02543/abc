var nationalityDao = {};
const Nationality = require('../model').nationalities;

nationalityDao.listNationality = (query, pageLimit) => {
  return Nationality.find({
      nationality: new RegExp(query, "i")
  },
  { _id: 0},
  {limit: parseInt(pageLimit)})
    .lean().exec()
}

module.exports = nationalityDao
