var publisherDao = {};
const Publisher = require('../model').publisher;

publisherDao.getAllPublishers = () => {
  return Publisher.find()
}

publisherDao.getTopPublishers = () => {
  return Publisher.find().sort({views: -1}).limit(10)
}

publisherDao.getPublisherDetailsById = (id) => {
  return Publisher.find({
    _id: id
  })
}


module.exports = publisherDao
