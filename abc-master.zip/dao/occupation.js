var occupationDao = {};
const Occupation = require('../model').occupations;

occupationDao.listOccupation = (query, pageLimit) => {
  return Occupation.find({
      occupation: new RegExp(query, "i")
  },
  { _id: 0},
  {limit: parseInt(pageLimit)})
    .lean().exec()
}

module.exports = occupationDao
