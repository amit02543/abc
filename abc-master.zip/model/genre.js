var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var GenreSchema = new Schema({
    genre: {
        type: String,
        required: true
    },
    count: {
        type: String,
        required: true
    },
    created: {
      type: Date,
      default: Date.now
    }
})

module.exports = mongoose.model('Genre', GenreSchema);
