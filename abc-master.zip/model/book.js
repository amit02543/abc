const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const BookSchema = new Schema({
    title: { type: String, required: true },
    author: { type: Array, required: true },
    contributors: Array,
    description: { type: String, required: true },
    publisher: { type: Array, required: true },
    publish_year: String,
    vol_info: String,
    edition: String,
    isbn: String,
    price: Number,
    pages: { type: Number, get: v => Math.round(v), set: v => Math.round(v), default: 0 },
    language: String,
    series_name: String,
    series_bundle: Array,
    // images: {
    //   small: String,
    //   big: String
    // },
    images: String,
    likes: { type: Number, get: v => Math.round(v), set: v => Math.round(v), default: 0 },
    dislikes: { type: Number, get: v => Math.round(v), set: v => Math.round(v), default: 0 },
    downloads: { type: Number, get: v => Math.round(v), set: v => Math.round(v), default: 0 },
    views: { type: Number, get: v => Math.round(v), set: v => Math.round(v), default: 0 },
    ratings: {
      rating_1: { type: Number, get: v => Math.round(v), set: v => Math.round(v), default: 0 },
      rating_2: { type: Number, get: v => Math.round(v), set: v => Math.round(v), default: 0 },
      rating_3: { type: Number, get: v => Math.round(v), set: v => Math.round(v), default: 0 },
      rating_4: { type: Number, get: v => Math.round(v), set: v => Math.round(v), default: 0 },
      rating_5: { type: Number, get: v => Math.round(v), set: v => Math.round(v), default: 0 }
    },
    reviews: Array,
    categories: { type: Array, required: true },
    tags: { type: Array, required: true },
    created_at: { type: Date, default: Date.now },
    updated_at: Date
})

// BookSchema.pre('save', function save(next) {
//   const book = this;
//   book.updated_at = Date.now;
//   console.log('pre save: ', book)
// })

module.exports = mongoose.model('Book', BookSchema);
