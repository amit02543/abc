var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var KeywordSchema = new Schema({
  keyword: {
      type: String,
      required: true
  }
})

module.exports = mongoose.model('Keyword', KeywordSchema);
