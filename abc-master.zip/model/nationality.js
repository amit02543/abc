var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var NationalitySchema = new Schema({
  nationality: {
      type: String,
      required: true
  }
})

module.exports = mongoose.model('Nationality', NationalitySchema);
