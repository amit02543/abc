var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var OccupationSchema = new Schema({
  occupation: {
      type: String,
      required: true
  }
})

module.exports = mongoose.model('Occupation', OccupationSchema);
