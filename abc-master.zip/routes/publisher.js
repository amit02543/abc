const express = require('express')
const publisherDao = require('../dao').publisher
const chalk = require('chalk')
const router = express.Router();


router.get('/all', (req, res, next) => {
  publisherDao.getAllPublishers()
  .then((publishers) => {
    res.send(publishers)
  })
  .catch((err) => {
    console.log(chalk.red('Catch block of getAllPublishers method: ', err.message))
    res.send('error')
  })
});

router.get('/top', (req, res, next) => {
  publisherDao.getTopPublishers()
  .then((publishers) => {
    res.send(publishers)
  })
  .catch((err) => {
    console.log(chalk.red('Catch block of getTopPublishers method: ', err.message))
    res.send('error')
  })
});

router.get('/:id', (req, res, next) => {
  console.log('id: ', req.params.id)
  publisherDao.getPublisherDetailsById(req.params.id)
    .then((publisher) => {
      console.log('then block of publisher: ', publisher)
      res.send(publisher)
    })
    .catch((err) => {
      console.log('catch block of publisher: ', err.message)
      res.send('error')
    })
})

module.exports = router
