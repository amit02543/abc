const express = require('express')
const router = express.Router();
const bluebird = require('bluebird');
const crypto = bluebird.promisifyAll(require('crypto'));
const nodemailer = require('nodemailer');
const passport = require('passport');

const User = require('../model/user');

router.get('/facebook', passport.authenticate('facebook', { scope: ['email', 'public_profile'] }));
router.get('/facebook/callback', passport.authenticate('facebook', { failureRedirect: '/account/login' }), (req, res) => {
  res.redirect(req.session.returnTo || '/account/profile/social');
});

router.get('/twitter', passport.authenticate('twitter'));
router.get('/twitter/callback', passport.authenticate('twitter', { failureRedirect: '/account/login' }), (req, res) => {
  res.redirect(req.session.returnTo || '/account/profile/social');
});


router.get('/google', passport.authenticate('google', { scope: 'profile email' }));
router.get('/google/callback', passport.authenticate('google', { failureRedirect: '/account/login' }), (req, res) => {
  res.redirect(req.session.returnTo || '/account/profile/social');
});

router.get('/github', passport.authenticate('github'));
router.get('/github/callback', passport.authenticate('github', { failureRedirect: '/account/login' }), (req, res) => {
  res.redirect(req.session.returnTo || '/account/profile/social');
});

router.get('/linkedin', passport.authenticate('linkedin', { state: 'SOME STATE' }));
router.get('/linkedin/callback', passport.authenticate('linkedin', { failureRedirect: '/account/login' }), (req, res) => {
  res.redirect(req.session.returnTo || '/account/profile/social');
});


module.exports = router
