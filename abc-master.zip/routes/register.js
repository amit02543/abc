const express = require('express')
const chalk = require('chalk')
const validators = require('../validators')
const cloudinary = require('cloudinary')
const multer = require('multer')
const path = require('path')
const fs = require('fs')
const upload = multer({dest: './upload/'});
const Messages = require('../constant/messages')
const bookQuery = require('../dao').book

const MAGIC_NUMBERS = {
    jpg: 'ffd8ffe0',
    jpg1: 'ffd8ffe1',
    png: '89504e47',
    gif: '47494638'
}

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
});

function checkMagicNumbers(magic) {
  console.log('magic: ', magic)
  if (magic == MAGIC_NUMBERS.jpg || magic == MAGIC_NUMBERS.jpg1 || magic == MAGIC_NUMBERS.png || magic == MAGIC_NUMBERS.gif) return true
}

const router = express.Router();

router.get('/', function(req, res, next) {
  req.app.locals.page1status="in-progress"
  res.redirect('/register/part-one')
})


router.get('/part-one', (req, res, next) => {
  req.app.locals.page1status="in-progress"
    res.render('reg-part-one', {
      title: 'Book Registration',
      data: req.app.locals.page1Data,
      message: 'Step 1: Book Details'
    })
})

router.post('/part-one', (req, res, next) => {
  validators.validateRegisterPage.validateRegistrationPartOne(req.body)
  .then((value) => {
    req.app.locals.page1status="completed";
    req.app.locals.page1Data = req.body;
    res.redirect('/register/part-two')
  })
  .catch((err) => {
    var errors = err.details;
    console.log(chalk.red('Error in post method: ', errors.length))
    var formattedError = errors.reduce((output,currentElem)=>{
  	   const fieldName = currentElem.path
      if(!output[fieldName]){
        output[fieldName] = []
      }
      output[fieldName].push(currentElem)
      return output
    },{})
    console.log(chalk.red("errors: ", formattedError))
    req.app.locals.page1status="error"
    req.flash('error', Messages.validationsFailed)
    res.render( 'reg-part-one', {
        title: 'Book Registration',
        data: req.body,
        message: 'Step 1: Book Details',
        errors: formattedError
    });
    //res.json({'uri': 'register', 'errorObj': formattedError})
  })
})

router.get('/part-two', (req, res) => {
  req.app.locals.page2status="in-progress"
    res.render('reg-part-two', {
      title: 'Book Registration',
      data: req.app.locals.page2Data,
      message: 'Step 2: Additional Details'
    })
})

router.post('/part-two', (req, res) => {
  validators.validateRegisterPage.validateRegistrationPartTwo(req.body)
  .then( (value) => {
    res.app.locals.page2status="completed"
    req.app.locals.page2Data = req.body;
    res.redirect('/register/part-three')
  })
  .catch( (err) => {
    var errors = err.details;
    console.log(chalk.red('Error in post method: ', errors.length))
    var formattedError = errors.reduce((output,currentElem)=>{
       const fieldName = currentElem.path
      if(!output[fieldName]){
        output[fieldName] = []
      }
      output[fieldName].push(currentElem)
      return output
    },{})
    console.log(chalk.red("errors: ", formattedError))
    res.app.locals.page2status="error"
    res.render( 'reg-part-two', {
        title: 'Book Registration',
        message: 'Step 2: Additional Details',
        data: req.body,
        errors: formattedError
    });
  })
})

router.get('/part-three', (req, res) => {
  res.app.locals.page3status="in-progress"
    res.render('reg-part-three', {
      title: 'Book Registration',
      data: req.app.locals.page3Data,
      message: 'Step 3: Series & Tags'
    })
})

router.post('/part-three', (req, res) => {
  validators.validateRegisterPage.validateRegistrationPartThree(req.body)
  .then( (value) => {
    res.app.locals.page3status="completed"
    req.app.locals.page3Data = req.body;
    res.redirect('/register/part-four')
  })
  .catch( (err) => {
    var errors = err.details;
    console.log(chalk.red('Error in post method: ', errors.length))
    var formattedError = errors.reduce((output,currentElem)=>{
       const fieldName = currentElem.path
      if(!output[fieldName]){
        output[fieldName] = []
      }
      output[fieldName].push(currentElem)
      return output
    },{})
    console.log(chalk.red("errors: ", formattedError))
    res.app.locals.page3status="error"
    res.render( 'reg-part-three', {
        title: 'Book Registration',
        data: req.body,
        message: 'Step 3: Series & Tags',
        errors: formattedError
    });
  })
})

router.get('/part-four', (req, res) => {
  res.app.locals.page4status="in-progress"
    res.render('reg-part-four', {
      title: 'Book Registration',
      data: req.app.locals.page4Data,
      message: 'Step 4: Upload Image'
    })
})

router.post('/part-four', (req, res, next) => {
  var upload = multer({
    storage: multer.memoryStorage()
  }).single('bookImg')
  upload(req, res, function(err) {
    var buffer = req.file.buffer
    var magic = buffer.toString('hex', 0, 4)
    var filename = req.file.fieldname + '-' + Date.now() + path.extname(req.file.originalname)

    if (checkMagicNumbers(magic)) {
      console.log('Condn: ', checkMagicNumbers(magic))
      fs.writeFile('./upload/' + filename, buffer, 'binary', function(err) {
        if (err) {
          console.log('error: ', err.message )
          throw err
        }
        console.log('filename: ', filename)
        cloudinary.uploader.upload('./upload/'+filename)
          .then((value) => {
            console.log('Result: ', value)
            res.app.locals.page4status="completed"
            req.app.locals.page4Data = value.url;
            res.redirect('/register/part-five')
          })
          .catch((err) => {
            console.log('Error: ', err)
            res.app.locals.page4status="error"
            res.render( 'reg-part-four', {
                title: 'Book Registration',
                message: 'Step 4: Upload Image',
                errMessage: "Upload Failed"
            });
          })
      })
    } else {
      //res.status(415).end('File is no valid')
      res.app.locals.page4status="error"
      res.render( 'reg-part-four', {
          title: 'Book Registration',
          message: 'Step 4: Upload Image',
          errMessage: "File is not valid"
      });
    }
  })

})

router.get('/part-five', (req, res) => {
  res.app.locals.page5status="in-progress"
  console.log(`page1: `, req.app.locals.email)
  res.render('reg-part-five', {
    title: 'Book Registration',
    message: 'Step 5: Summary',
    page1data: req.app.locals.page1Data,
    page2data: req.app.locals.page2Data,
    page3data: req.app.locals.page3Data,
    page4data: req.app.locals.page4Data
  })
})


router.post('/part-five', (req, res, next) => {
  console.log('part 5: ', req.body)
  bookQuery.insertBookDeails(req.body)
  .then((value) => {
    res.redirect('/thank-you')
  })
  .catch((err) => {
    res.render('reg-part-five', {
      title: 'Book Registration',
      message: 'Step 5: Summary',
      error: 'Currently we are unable to insert data. Please try again after some time.',
      page1data: req.app.locals.page1Data,
      page2data: req.app.locals.page2Data,
      page3data: req.app.locals.page3Data,
      page4data: req.app.locals.page4Data
    })
  })
})



module.exports = router
