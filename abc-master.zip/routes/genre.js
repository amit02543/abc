const express = require('express')
const genreDao = require('../dao').genre
const chalk = require('chalk')
const router = express.Router();


router.get('/all', (req, res, next) => {
  genreDao.getAllGenres()
  .then((genres) => {
    res.render("genre", {
      title: "Genres - All",
      genres: genres
    })
  })
  .catch((err) => {
    console.log(chalk.red('Catch block of getAllGenres method: ', err.message))
    res.send('error')
  })

});

router.get('/top', (req, res, next) => {
  genreDao.getTopGenres()
  .then((genres) => {
    res.render("genre", {
      title: "Genres - Top",
      genres: genres
    })
  })
  .catch((err) => {
    console.log(chalk.red('Catch block of getTopGenres method: ', err.message))
    res.send('error')
  })
});

router.get('/popular', (req, res, next) => {
  genreDao.getPopularGenres()
  .then((genres) => {
    res.render("genre", {
      title: "Genres - Popular",
      genres: genres
    })
  })
  .catch((err) => {
    console.log(chalk.red('Catch block of getTopGenres method: ', err.message))
    res.send('error')
  })
});


router.get('/count', (req, res, next) => {
  genreDao.getCountWiseGenres()
  .then((genres) => {
    res.render("genre", {
      title: "Genres - Count Wise",
      genres: genres
    })
  })
  .catch((err) => {
    console.log(chalk.red('Catch block of getTopGenres method: ', err.message))
    res.send('error')
  })
});

router.get('/:genre', (req, res, next) => {
  console.log('genre: ', req.params.genre)
  genreDao.getGenre(req.params.genre)
    .then((books) => {
      console.log('then block of genre: ', books)
      res.send(books)
    })
    .catch((err) => {
      console.log('catch block of genre: ', err.message)
    })
})

module.exports = router
