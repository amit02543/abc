module.exports = {
  loginSuccessMsg: 'Success! You are logged in.',
  signupExistingUserErrorMsg: 'Account with that email address already exists.',
  loginFailedMessage: "The username and password you entered is incorrect or does not exist. Please verify and reenter your username and password.",
  existingUserErrorMsg: 'The email address you have entered is already associated with an account.',
  passwordChangeSuccessMsg: 'Password has been changed.',
  passwordIncorrectErrorMsg: "Enter password is not correct. Please try again.",
  profileUpdateSuccessMsg: 'Profile information has been updated.',
  accountDeletedMsg: 'Your account has been deleted.',
  pswdTokenExpireMg: 'Password reset token is invalid or has expired.',
  pswdResetSuccessMsg: 'Success! Your password has been changed.',
  invalidEmailErrorMsg: 'Account with that email address does not exist.',

  adminEmailAddress: `Admin Book Bank<${process.env.ADMIN_EMAIL}>`,
  queryEmailAddress: `Query Book Bank<${process.env.ADMIN_EMAIL}>`,
  successChangePswdSubject: 'Your Book Bank password has been changed',
  resetPasswordSubject: 'Reset your password on Book Bank',
  querySubject: 'Book Bank Query :',

  facebookExistingUser: 'There is already a Facebook account that belongs to you. Sign in with that account or delete it, then link it with your current account.',
  facebookSuccessMsg: "Facebook account has been linked.",
  facebookExistingEmailUser: 'There is already an account using this email address. Sign in to that account and link it with Facebook manually from Account Settings.',

  twitterExistingUser: 'There is already a Twitter account that belongs to you. Sign in with that account or delete it, then link it with your current account.',
  twitterSuccessMsg: 'Twitter account has been linked.',
  twitterExistingEmailUser: 'There is already a Google account that belongs to you. Sign in with that account or delete it, then link it with your current account.',

  googleExistingUser: 'There is already a Facebook account that belongs to you. Sign in with that account or delete it, then link it with your current account.',
  googleSuccessMsg: 'Google account has been linked.',
  googleExistingEmailUser: 'There is already an account using this email address. Sign in to that account and link it with Google manually from Account Settings.',

  githubExistingUser: 'There is already a GitHub account that belongs to you. Sign in with that account or delete it, then link it with your current account.',
  gihubSuccessMsg: 'GitHub account has been linked.',
  githubExistingEmailUser: 'There is already an account using this email address. Sign in to that account and link it with GitHub manually from Account Settings.',

  linkedinExistingUser: 'There is already a LinkedIn account that belongs to you. Sign in with that account or delete it, then link it with your current account.',
  linkedinSuccessMsg: 'LinkedIn account has been linked.',
  linkedinExistingEmailUser: 'There is already an account using this email address. Sign in to that account and link it with LinkedIn manually from Account Settings.',

  resetPasswordTextPre: `<p>We received a request to reset the password associated with this email address. If you made this request, please follow the instructions below</p><p>If you did not request to have your password reset, please ignore this email and your password will remain unchanged.</p><p><b>Click the button below to reset your password:</b></p><p style="margin: 40px 0;"><a style="color: #fff; background: #337ab7; padding: 12px 30px; border-radius: 4px; text-decoration: none; font-weight: 600;"  href=http://`,
  resetPasswordTextPost: `</p><p style="margin-top:20px">If clicking the link doesn't work, you can copy and paste the below link into your browser's address window, or retype it there.</p>`,
  resetPasswordInstruction: `<p>Once you have returned to Book Bank, we will give you instructions for resetting your password.</p><p>This link is valid for next 24 hours.</p><br/><p>Thank you for visiting <b><a href="${process.env.APP_URL}">Book Bank</b></a></p><br/><p><b>Regards,</b><br/><b><a href="${process.env.APP_URL}"> Book Bank Team </a></b></p>`,

  resetPswdSuccessTxtPre: '<br/><br/><p>This is a confirmation that the password for your account<b>',
  resetPswdSuccessTxtPost: `</b>has just been changed.</p><p>If you did not make this change, please reset your password to get back into your account.</p><p style="margin: 40px 0;"><a style="color: #fff; background: #337ab7; padding: 12px 30px; border-radius: 4px; text-decoration: none; font-weight: 600;" href="${process.env.APP_URL}account/forgot">Reset Your Password</a></p><p>Thank you for visiting <b><a href="${process.env.APP_URL}">Book Bank</b></a></p><br/><p><b>Regards,<b><br><b><a href="${process.env.APP_URL}"> Book Bank Team </a></b></p>`,

  localTunnel: 'lt --port 4040',

  thankYouMessage: "We truly care about your feedback. This is how we - together - make Book Bank better for everyone. You tell us what to improve your experience and we make sure that is made for you. Thank you for being an active contributor to the Book Bank Community.",
  contactThankyou: "We have received your query. We will get back to you within 2 business days.",
  bookThankyou: `Thank you very much for your help and for your support! <br>Without your support and contribution, we would never have achieved the success we are enjoying today.`,
  authorThankyou: `Thank you very much for your help and for your support! <br>Without your support and contribution, we would never have achieved the success we are enjoying today.`,
  publisherThankyou: `Thank you very much for your help and for your support! <br>Without your support and contribution, we would never have achieved the success we are enjoying today.`,

  invalidImageErrorMsg: "File format is not valid. Image should be in .PNG/.JPG/.JPEG/.GIF format.",
  noResultErrorMsg: 'No Result found. Try Again.',
  bookUpdateSuccesMsg: 'Book details updated Successfully',
  reviewUpateSuccessMsg: 'Thank you for your review.',
  reviewUpdateFailedMsg: 'Book review updation failed.',
  bookIdConflictError: 'Book Id and Id must be same.',

  validationsFailed: 'There are some errors in fields.',
  queryLenError: "Error: Query must contains 2 or more characters.",

  imgUpdateSuccessMsg: "Update successful!!!",
  imgUpdateFailedMsg: "Unable to update image.",

  number: '9304062189'

}


// facebook
// clientID: '644817119241329',
// clientSecret: '2e883753927fbc3172f69d1bb0bfaf8f',
//
// google
// clientID: '743031052279-l0l1eltacbk2287gdqlbq442r31bh4v6.apps.googleusercontent.com',
// clientSecret: 'LA51mCii5os9QQ6mRznT39eD',
//
//
// GitHub+
// clientID: '4f962a13bd4bf47c7bab',
// clientSecret: 'ee1343864e708b6b131ba1eafdd5a4450fa35393',
//
// twitter
// consumerKey: 'CAeKwbQfyBZec3xsOWtfwJ7sX',
// consumerSecret: 'PshzNYPIFBkmRS7oCaQV10Gl6LHbI71HejxEBhMsK78a1pJrjT',
//
// My Access Token:	178727827-HRHRuDhTXDrRy7PxrRzYJADkMQwTZEyPAbDPAKi2
// My Access Token Secret:	hrk50HIelxyXptLsygR155rnj5HzB2I4lRE0614wnnv4f
//
//
//
// LinkedIn
// clientID: '816cgil3pltodr',
// clientSecret: 'uhDYQoxKEJmsKmKK',
