const Joi = require('joi')
const joiOptions = { convert: true, abortEarly: false };

const userQueryValidatorSchema = Joi.object().keys({
  fullName: Joi.string().required().min(3).max(50),
  email: Joi.string().email().required(),
  subject: Joi.string().allow('').min(3).max(100).optional(),
  message: Joi.string().min(20).max(500).required()
})

const userQueryValidator = (query) => {
  return new Promise( (resolve, reject) => {
    Joi.validate(query, userQueryValidatorSchema, joiOptions, (err, value) => {
      if (err) {
        return reject(err)
      } else {
        return resolve(value)
      }
    })
  })
}

module.exports = {
  userQueryValidator:userQueryValidator
}
